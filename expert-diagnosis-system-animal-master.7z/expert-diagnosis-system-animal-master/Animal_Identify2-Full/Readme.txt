﻿Để 2 file Luat.txt và Sukien.txt trong thư mục debug nhé.

-Vương Đức Hiền-
-vuonghienuit.wordpress.com-