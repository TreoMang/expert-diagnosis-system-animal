from pyknow import *
import file_dict as f

class Characteristics(Fact):
    """ Dac diem nhan dang dong vat """
    pass

class Diagnosis_animals(KnowledgeEngine):

    # print(bear)

    @Rule(Characteristics(name = 'platypus'))
    def platypus(self):
        print('platypus')

    @Rule(AND(Characteristics(hair=1),
              Characteristics(toothed=0),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=4),
              Characteristics(predator=1)))
    def _platypus(self):
        self.declare(Characteristics(name='platypus'))

    #######################################################
    @Rule(Characteristics(name='bear'))
    def bear(self):
        print('bear')

    @Rule(AND(Characteristics(hair=1),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=0),
              Characteristics(eggs=0),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=4),
              Characteristics(predator=1)))
    def _bear(self):
        self.declare(Characteristics(name='bear'))

    #######################################################
    @Rule(Characteristics(name = 'leopard'))
    def leopard(self):
        print('leopard')

    @Rule(AND(Characteristics(hair=1),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=0),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=4),
              Characteristics(predator=1)))
    def _leopard(self):
        self.declare(Characteristics(name='leopard'))

    #######################################################
    @Rule(Characteristics(name = 'gorilla'))
    def gorilla(self):
        print('gorilla')

    @Rule(AND(Characteristics(hair=1),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=0),
              Characteristics(eggs=0),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=2),
              Characteristics(predator=0)))
    def _gorilla(self):
        self.declare(Characteristics(name='gorilla'))

    #######################################################
    @Rule(Characteristics(name = 'elephant'))
    def elephant(self):
        print('elephant')

    @Rule(AND(Characteristics(hair=1),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=0),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=4),
              Characteristics(predator=0)))
    def _elephant(self):
        self.declare(Characteristics(name='elephant'))

    #######################################################
    @Rule(Characteristics(name = 'dolphin'))
    def dolphin(self):
        print('dolphin')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=0),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=1),
              Characteristics(legs=0),
              Characteristics(predator=1)))
    def _dolphin(self):
        self.declare(Characteristics(name='dolphin'))

    #######################################################
    @Rule(Characteristics(name = 'octopus'))
    def octopus(self):
        print('octopus')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=0),
              Characteristics(tail=0),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=8),
              Characteristics(predator=1)))
    def _octopus(self):
        self.declare(Characteristics(name='octopus'))

    #######################################################
    @Rule(Characteristics(name = 'frog'))
    def frog(self):
        print('frog')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=0),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=4),
              Characteristics(predator=1)))
    def _frog(self):
        self.declare(Characteristics(name='frog'))

    #######################################################
    @Rule(Characteristics(name = 'turtle'))
    def turtle(self):
        print('turtle')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=4),
              Characteristics(predator=0)))
    def _turtle(self):
        self.declare(Characteristics(name='turtle'))

    #######################################################
    @Rule(Characteristics(name = 'ladybird'))
    def ladybird(self):
        print('ladybird')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=0),
              Characteristics(tail=0),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=1),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=6),
              Characteristics(predator=1)))
    def _ladybird(self):
        self.declare(Characteristics(name='ladybird'))

    #######################################################
    @Rule(Characteristics(name = 'duck'))
    def duck(self):
        print('duck')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=1),
              Characteristics(airborne=1),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=2),
              Characteristics(predator=1)))
    def _duck(self):
        self.declare(Characteristics(name='duck'))

    #######################################################
    @Rule(Characteristics(name = 'lobster'))
    def lobster(self):
        print('lobster')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=0),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=6),
              Characteristics(predator=1)))
    def _lobster(self):
        self.declare(Characteristics(name='lobster'))

    #######################################################
    @Rule(Characteristics(name = 'snake'))
    def snake(self):
        print('snake')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=0),
              Characteristics(predator=1)))
    def _snake(self):
        self.declare(Characteristics(name='snake'))

    #######################################################
    @Rule(Characteristics(name = 'carp'))
    def penguin(self):
        print('carp')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=1),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=1),
              Characteristics(legs=0),
              Characteristics(predator=1)))
    def _carp(self):
        self.declare(Characteristics(name='carp'))

    #######################################################
    @Rule(Characteristics(name = 'penguin'))
    def penguin(self):
        print('penguin')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=1),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=1),
              Characteristics(airborne=0),
              Characteristics(domestic=1),
              Characteristics(fins=0),
              Characteristics(legs=2),
              Characteristics(predator=1)))
    def _penguin(self):
        self.declare(Characteristics(name='penguin'))

    #######################################################
    @Rule(Characteristics(name = 'earthworm'))
    def penguin(self):
        print('earthworm')

    @Rule(AND(Characteristics(hair=0),
              Characteristics(toothed=0),
              Characteristics(backbone=0),
              Characteristics(tail=1),
              Characteristics(eggs=1),
              Characteristics(feathers=0),
              Characteristics(airborne=0),
              Characteristics(domestic=0),
              Characteristics(fins=0),
              Characteristics(legs=0),
              Characteristics(predator=0)))
    def _earthworm(self):
        self.declare(Characteristics(name='earthworm'))

    #######################################################


    @Rule(OR(
        AND(Characteristics(hair = 1),Characteristics(eggs = 1)),
        AND(Characteristics(hair = 1), Characteristics(teethed = 0))))
    def maybePlatypus(self):
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(eggs = 1))
        self.declare(Characteristics(teethed = 0))
        self.declare(Characteristics(backbone = 1))
        #print("something")

    @Rule(Characteristics(hair = 1))
    def hair(self):
        self.declare(Characteristics(backbone = 1))
        self.declare(Characteristics(airborne = 0))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(fins = 0))
        # print(self.facts)


    @Rule(Characteristics(toothed = 1))
    def toothed(self):
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(backbone = 1))
        self.declare(Characteristics(airborne = 0))

    @Rule(Characteristics(backbone = 1))
    def backbone(self):
        print("co xuong cung co suy ra duoc cai gi dau")

    @Rule(Characteristics(tail = 0))
    def tail0(self):
        self.declare(Characteristics(predator = 1))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(fins = 0))

    @Rule(Characteristics(tail = 1))
    def tail(self):
        print("co duoi cung vay thoi a")

    @Rule(Characteristics(eggs = 1))
    def eggs(self):
        print("de trung thi de chua biet lam sao")

    @Rule(Characteristics(eggs = 0))
    def eggs0(self):
        self.declare(Characteristics(backbone = 1))
        self.declare(Characteristics(hair = 1))
        self.declare(Characteristics(toothed = 1))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(airborne = 0))

    @Rule(Characteristics(feathers = 1))
    def feathers(self):
        self.declare(Characteristics(eggs = 1))
        self.declare(Characteristics(backbone = 1))
        self.declare(Characteristics(hair = 0))
        self.declare(Characteristics(toothed = 0))
        self.declare(Characteristics(tail = 1))
        self.declare(Characteristics(fins = 0))

    @Rule(Characteristics(airborne = 1))
    def airborne(self):
        self.declare(Characteristics(eggs = 1))
        self.declare(Characteristics(toothed = 0))
        self.declare(Characteristics(hair = 0))
        self.declare(Characteristics(fins = 0))

    @Rule(Characteristics(fins = 1))
    def fins(self):
        self.declare(Characteristics(hair = 0))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(toothed = 1))
        self.declare(Characteristics(backbone = 1))
        self.declare(Characteristics(tail = 1))
        self.declare(Characteristics(airborne = 0))
        self.declare(Characteristics(domestic = 1))
        self.declare(Characteristics(legs = 0))
        self.declare(Characteristics(predator = 1))

    @Rule(Characteristics(legs = 0))
    def legs0(self):
        self.declare(Characteristics(tail = 1))
        self.declare(Characteristics(hair = 0))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(airborne = 0))

    @Rule(Characteristics(legs = 4))
    def legs4(self):
        self.declare(Characteristics(backbone = 1))
        self.declare(Characteristics(airborne = 0))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(fins = 0))

    @Rule(Characteristics(legs = 6))
    def legs6(self):
        self.declare(Characteristics(predator = 1))
        self.declare(Characteristics(hair = 0))
        self.declare(Characteristics(feathers  = 0))
        self.declare(Characteristics(eggs = 1))
        self.declare(Characteristics(fins = 0))
        self.declare(Characteristics(backbone = 0))

    @Rule(Characteristics(legs = 8))
    def legs8(self):
        self.declare(Characteristics(predator = 1))
        self.declare(Characteristics(hair = 0))
        self.declare(Characteristics(feathers = 0))
        self.declare(Characteristics(tail = 0))
        self.declare(Characteristics(eggs = 1))
        self.declare(Characteristics(toothed = 0))
        self.declare(Characteristics(fins = 0))
        self.declare(Characteristics(domestic = 1))




watch('RULES','FACTS')
engine = Diagnosis_animals()
bear = f.diction['bear'].copy()
del bear['name']
engine.reset()  # Prepare the engine for the execution.
# engine.declare(Characteristics(hair = 1))
# engine.declare(Characteristics(feathers = 1))
# engine.declare(Characteristics(airborne = 1))
#engine.declare(Characteristics(hair = 1))
engine.declare(Characteristics(hair = 1))
engine.declare(Characteristics(toothed = 0))
engine.declare(Characteristics(predator = 1))
engine.declare(Characteristics(legs = 4))
engine.facts
# print(engine.facts)
engine.run()  # Run it!